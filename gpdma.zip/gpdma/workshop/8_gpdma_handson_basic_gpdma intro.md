# 1. GPDMA + ADC

 We create simple example where first GPDMA transfersdata from ADC. 

![adc dma description](./img/adc_dma_desc.json)
