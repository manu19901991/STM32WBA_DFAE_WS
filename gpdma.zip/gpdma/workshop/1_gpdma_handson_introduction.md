# GPDMA handson copysheet 

Our goal is to learn about GPDMA features

* **New Linked-list feature**
* **Legacy Standard DMA aproach** (optional)

Overview of advanced features (extention of our handson)

* Triggers
* Events (optional)
* 2D addresing (optional)

And we will create application like this:

![final application](./img/complete_application.json)
