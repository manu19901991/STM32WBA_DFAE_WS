# Extending our list

In this part we will extend our example. By adding UART to send received `data` buffer.

How to do it:

1. We add **UART** and configure it.
2. We add new node to our **GPDMA**

![adc dma uart](./img/adc_dma_uart.json)

Now return back to MX
