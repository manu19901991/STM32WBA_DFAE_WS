# 1. GPDMA + ADC

 We create simple example where first GPDMA transfersdata from ADC. 
 Wew ill have ADC with 4 channels and we will transfer 64times with GPDMA. So 16samples for each channel.

![adc dma description](./img/adc_dma_desc.json)

