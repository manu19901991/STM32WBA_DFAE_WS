# GPDMA links

To know about GPDMA more. 
You can use 

1. [GPDMA application note](https://www.st.com/resource/en/application_note/an5593-how-to-use-the-gpdma-for-stm32u575585-microcontrollers-stmicroelectronics.pdf)

1. [GPDMA simple step by step examples](https://rristm.github.io/tomas_materials_v2/RRISTM/gpdma)

